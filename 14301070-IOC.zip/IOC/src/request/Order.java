package request;

import java.io.Serializable;

public class Order implements Serializable{
	public enum OrderType{
		SUBSCRIBE,
		LOG_IN,
		UPDATE,
		LOOKUP
	}
	
	private Object client;
	private OrderType type;
	private UpdateParams params;
	
	public Order(){
		type = OrderType.SUBSCRIBE;
		params = null;
		client = null;
	}
	
	public Order(OrderType orderType, UpdateParams updateParams, Object object) {
		type = orderType;
		params = updateParams;
		this.client = object;
	}

	public OrderType getType() {
		return type;
	}

	public void setType(OrderType type) {
		this.type = type;
	}

	public UpdateParams getParams() {
		return params;
	}

	public void setParams(UpdateParams params) {
		this.params = params;
	}

	public Object getClient() {
		return client;
	}

	public void setClient(Object client) {
		this.client = client;
	}
	
}
