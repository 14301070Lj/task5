package request;

public enum ProfileItem {
	name,
	password,
	tel_phone,
	email,
	
}
