package request;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class UpdateParams implements Serializable{
	
	private static final long serialVersionUID = 791702868L;
	List<ProfileItemPair> items;
	
	public UpdateParams(){
		items = new ArrayList<>();
	}
	
	public void add(ProfileItemPair item) {
		items.add(item);
	}
	
	public boolean remove(ProfileItemPair item){
		for (ProfileItemPair e : items) {
			if(e == item){
				return items.remove(e);
			}
		}
		return false;
	}

	
	public boolean remove(ProfileItem item) {
		for(int i = 0; i < items.size(); i++){
			if(items.get(i).getItem()==item){
				items.remove(i);
				return true;
			}
		}
		return false;
	}
	
	
	public Object getItemData(ProfileItem item){
		Object data = null;

		for (ProfileItemPair itemPair : items) {
			if(itemPair.getItem()==item){
				data = itemPair.getData();
				break;
			}
		}
		return data;
	}
	
	
	public List<ProfileItemPair> getParams() {
		return items;
	}
}
