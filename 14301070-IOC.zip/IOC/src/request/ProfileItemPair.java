package request;

import java.io.Serializable;


public class ProfileItemPair implements Serializable{
	
	private static final long serialVersionUID = -665987556L;
	private ProfileItem item;
	private Object data;
	
	
	public ProfileItemPair(ProfileItem item, Object data){
		this.data = data;
		this.item = item;
	}

	public ProfileItem getItem() {
		return item;
	}

	public void setItem(ProfileItem item) {
		this.item = item;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}
	
}
