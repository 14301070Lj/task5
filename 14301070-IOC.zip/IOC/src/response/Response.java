package response;

import java.io.Serializable;

public class Response implements Serializable {
	
	private static final long serialVersionUID = -7081508166590L;

	public enum ResType{
		LOGIN,
		SUBSCRIBE,
		UPDATE,
		ERROR
	}
	
	private String msg;
	private ResType type;
	
	public Response(){
		
	}
	
	public Response(String msg, ResType type){
		this.msg = msg;
		this.type = type;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public ResType getType() {
		return type;
	}

	public void setType(ResType type) {
		this.type = type;
	}
}
