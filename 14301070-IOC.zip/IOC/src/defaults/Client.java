package defaults;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

import request.Order;
import response.Response;

public interface Client extends Remote{
	
	public void inform(Response res) throws RemoteException;
}
