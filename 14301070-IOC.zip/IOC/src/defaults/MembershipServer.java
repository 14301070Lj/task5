package defaults;

import java.rmi.Remote;
import java.rmi.RemoteException;

import request.Order;

public interface MembershipServer extends Remote{

	public static final String URL = "rmi://localhost:8888/RMIServer";
	public void register(Client client) throws RemoteException;
	public void unregister(Client client) throws RemoteException;
	public void addOrder(Order order) throws RemoteException;
}
