package defaults;

import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import request.Order.OrderType;
import request.ProfileItem;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashSet;
import java.util.concurrent.LinkedBlockingQueue;
import request.Order;
import response.Response;
import response.Response.ResType;


public class MembershipServerImpl extends UnicastRemoteObject implements MembershipServer, Runnable{
	
	private HashSet clients;
	private LinkedBlockingQueue<Order> orders;
	//max_messages���洢��
	public static final int max_messages = 500;	
	public static final int port = 8888;
	
	protected MembershipServerImpl() throws RemoteException {
		super();
		
		clients = new HashSet<>();
		orders = new LinkedBlockingQueue<>(max_messages);
	}

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			System.setSecurityManager(new RMISecurityManager());
			LocateRegistry.createRegistry(port);
			
			MembershipServerImpl serverImpl = new MembershipServerImpl();
			Naming.bind(URL, serverImpl);
			
			System.out.println("MembershipServer run!");
			new Thread(serverImpl).run();
			
		}catch (Exception e) {
		
			e.printStackTrace();
		}
	}

	
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true){
			if(orders.isEmpty()){
				try {
					Thread.sleep(20);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else{
				try {
					Order order = orders.take();
					Client clt = (Client)order.getClient();
					//
					clt.inform(handleOrder(order));
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	
	
	@Override
	public void register(Client client) throws RemoteException {
		// log
		System.out.println("Client is added, Client information: " + client.toString());
		//
		clients.add(client);
	}

	
	
	@Override
	public void unregister(Client client) throws RemoteException {
		// log
		System.out.println("Client is removed, Client information: " + client.toString());
		//
		clients.remove(client);
	}

	
	
	@Override
	public void addOrder(Order order) throws RemoteException {
		// TODO Auto-generated method stub
		Client clt = (Client)order.getClient();
		if(clients.contains(clt)){
			orders.add(order);
		}else{
			clt.inform(new Response("error��this is not register!", ResType.ERROR));
		}
	}
	
	
	
	public Response handleOrder(Order order){
		Response response = new Response();
		switch (order.getType()) {
			case LOG_IN:
				response.setType(ResType.LOGIN);
				String name = (String) order.getParams().getItemData(ProfileItem.name);
				String pwd = (String) order.getParams().getItemData(ProfileItem.password);
				System.out.println("Handle order, name: " + name + " password: " + pwd);
			
				response.setMsg("success!");
				
				break;
				
				
				
			case SUBSCRIBE:
				response.setType(ResType.SUBSCRIBE);
				break;
			case UPDATE:
				response.setType(ResType.UPDATE);
				break;
	
			default:
				break;
		}
			
		return response;
	}

	
}
