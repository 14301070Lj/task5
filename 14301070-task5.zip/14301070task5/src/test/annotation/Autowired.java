package test.annotation;

import java.lang.annotation.*;

public @interface Autowired {

}
