package test.edu.javaee.spring;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import dev.edu.javaee.spring.bean.BeanDefinition;
import dev.edu.javaee.spring.bean.PropertyValue;
import dev.edu.javaee.spring.bean.PropertyValues;
import dev.edu.javaee.spring.factory.BeanFactory;
import dev.edu.javaee.spring.factory.XMLBeanFactory;
import test.boss;

public class BeanFactoryTest {

	
	//
	@Test
	public void testXML(){
		try{
			BeanFactory beanFactory = new XMLBeanFactory("bean.xml");
			boss boss = (boss) beanFactory.getBean("boss");
			
			assertEquals(boss.toString(), 
					"this boss has the car is red with 001 and in office 001");
		}catch (Exception e) {
			// TODO: handle exception
		}
		
	}

}
