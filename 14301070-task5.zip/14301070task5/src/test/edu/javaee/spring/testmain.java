package test.edu.javaee.spring;

import dev.edu.javaee.spring.factory.BeanFactory;
import dev.edu.javaee.spring.factory.XMLBeanFactory;
import test.boss;
//import test.car;
//import test.office;

public class testmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			BeanFactory beanFactory = new XMLBeanFactory("bean.xml");
			boss boss = (boss) beanFactory.getBean("boss");
			
			System.out.println(boss.toString());
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
