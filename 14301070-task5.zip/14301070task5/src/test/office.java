package test;



public class office {
    private String officeNo;

	



	public String getOfficeNo() {
		return officeNo;
	}




	public void setOfficeNo(String officeNo) {
		this.officeNo = officeNo;
	}





	public String toString(){
		return "office " +officeNo;
	}

}
