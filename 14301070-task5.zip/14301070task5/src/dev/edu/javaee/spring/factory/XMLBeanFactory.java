package dev.edu.javaee.spring.factory;


import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.Node;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import dev.edu.javaee.spring.bean.BeanDefUnfinish;
import dev.edu.javaee.spring.bean.BeanDefinition;
import dev.edu.javaee.spring.bean.BeanUtil;
import dev.edu.javaee.spring.bean.PropertyValue;
import dev.edu.javaee.spring.bean.PropertyValues;
import test.car;
import test.annotation.Autowired;

public class XMLBeanFactory extends AbstractBeanFactory{
	public XMLBeanFactory(){}
	
	public XMLBeanFactory(String XMLPath) throws Exception {
		// TODO Auto-generated constructor stub
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document doc = db.parse(new File(XMLPath));
		List<BeanDefUnfinish> bufList = new ArrayList<>();
		//
		NodeList list = doc.getElementsByTagName("bean");
		//
		for(int i = 0; i < list.getLength(); i++){
			Element element = (Element) list.item(i);
			//get properties
			String idValue, classValue;
			idValue = element.getAttribute("id");
			classValue = element.getAttribute("class");
			//
			NodeList properties = element.getElementsByTagName("property");
//			System.out.println("id: " + idValue + " name: " + classValue);
//			System.out.println("Found : " + properties.getLength());
			//
			BeanDefinition bdf = new BeanDefinition();
			bdf.setBeanClassName(classValue);
			PropertyValues pvs = new PropertyValues();
			boolean found = true;
			//bean unfinshed for ref
			BeanDefUnfinish buf = new BeanDefUnfinish(idValue, bdf);
			
			for(int j = 0; j < properties.getLength(); j++){
				Element e = (Element) properties.item(j);
				PropertyValue pv = new PropertyValue();
				String refName = e.getAttribute("ref");
				String name = e.getAttribute("name");
				String value = e.getAttribute("value");
				//
				pv.setName(name);
				if(!refName.isEmpty()){
					String clsName = BeanUtil.getClassName(refName);
					if(clsName == null){
						//
						found = false;
						buf.put(pv, refName);
					}else{
						Object object = Class.forName(clsName).newInstance();
						pv.setValue(object);
						pvs.AddPropertyValue(pv);
					}
				}else{
					pv.setValue(value);
					pvs.AddPropertyValue(pv);
				}
			}
			//
			bdf.setPropertyValues(pvs);
			if(found){
				//System.out.println(idValue + " is registered");
				registerBeanDefinition(idValue, bdf);
			}else{
				bufList.add(buf);
			}
		}
		
		//remain unregistered bean
		if(!bufList.isEmpty()){
			for (BeanDefUnfinish b : bufList) {
				b.setAllRefClasses(this);
			}
		}
	}
	
	
	@Override
	protected BeanDefinition GetCreatedBean(BeanDefinition beanDefinition) {
		String beanClassName = beanDefinition.getBeanClassName();
		try {
			// set BeanClass for BeanDefinition
			Class<?> beanClass = Class.forName(beanClassName);
			beanDefinition.setBeanClass(beanClass);
			// set Bean Instance for BeanDefinition
			Object bean = beanClass.newInstance();	
			
			//
			List<PropertyValue> fieldDefinitionList = beanDefinition.getPropertyValues().GetPropertyValues();
			//check
			if(beanClass.getName().equals("test.boss")){
				for(PropertyValue propertyValue: fieldDefinitionList)
				{
					BeanUtil.setField(bean, propertyValue.getName(), propertyValue.getValue());
				}
				//
				beanDefinition.setBean(bean);
				return beanDefinition;
			}
			
			for(PropertyValue propertyValue: fieldDefinitionList)
			{
				BeanUtil.invokeSetterMethod(bean, propertyValue.getName(), propertyValue.getValue());
			}
			
			beanDefinition.setBean(bean);
			
			return beanDefinition;
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
